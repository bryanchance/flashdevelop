﻿	local var accessibilityPropertyNames : Array;
