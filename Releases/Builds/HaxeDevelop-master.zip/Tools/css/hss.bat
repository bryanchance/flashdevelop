@hss %*
:: hss <options> in