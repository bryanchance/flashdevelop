interface ArrayParam {
}